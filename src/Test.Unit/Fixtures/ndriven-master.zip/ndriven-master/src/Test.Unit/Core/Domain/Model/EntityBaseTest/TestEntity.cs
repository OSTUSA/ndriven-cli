﻿using Core.Domain.Model;

namespace Test.Unit.Core.Domain.Model.EntityBaseTest
{
    public class TestEntity : EntityBase<TestEntity>
    {

    }
}
