﻿namespace Test.Unit.Infrastructure.IoC.NHibernate
{
    public class ClassWithNoAttribute
    {
    }
}
