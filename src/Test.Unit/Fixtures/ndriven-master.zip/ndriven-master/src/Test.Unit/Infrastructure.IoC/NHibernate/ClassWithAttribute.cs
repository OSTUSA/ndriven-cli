﻿using Infrastructure.NHibernate;

namespace Test.Unit.Infrastructure.IoC.NHibernate
{
    [SessionFactory("Default")]
    public class ClassWithAttribute
    {
    }
}
